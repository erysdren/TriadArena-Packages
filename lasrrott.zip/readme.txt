
Rise of the Triad - Lasersoft Shareware Levels (LASRROTT.ZIP)

Copyright (c) 1995/99 Apogee Software, Ltd.
All Rights Reserved


ACKNOWLEDGEMENTS
----------------

"Rise of the Triad" and "Rise of the Triad - Dark War" are Copyright (c) 1995/1999 Apogee Software, Ltd.

All other brands and product names are trademarks or registered trademarks of their respective holders.


BACKGROUND
----------

Back in early 1995 when Rise of the Triad was a new game, there was a special shareware version of the game produced entitled "Rise of the Triad: The HUNT Begins Deluxe Edition".  The game itself was the same, the only difference between the regular shareware and the deluxe was the inclusion of 6 additional levels (3 regular & 3 Comm-bat) in the deluxe version that never appeared in any other variant of the game.  The six levels are entitled:

Regular : Prelude to a Kill, Jumpin Jehoshapat, & Gadzooks!
Comm-Bat: The Siege, The Box, Rise & Tide

All 6 levels were designed by Tom Hall, and you can use these either on your registered Rise of the Triad game, or on the shareware edition.  Instructions on how to load these levels are shown below.  The other levels in these level packs are the existing shareware levels - these extras are in addition to the shareware levels that are already in your game.

In October of 1999, these levels were finally released to the general public, as this product is no longer sold commercially.


INSTRUCTIONS FOR REGISTERED VERSION
-----------------------------------

This procedure is the same no matter what registered version you have.

1) Copy the two level files (huntbgn2.rtl & huntbgn2.rtc) to your Rise of the Triad game directory.
2) Run the setup program by entering "Setup" and hit return.
3) Select the "Use Modified Stuff" menu option and hit return.
4) Select either "Choose Alternate Game Levels" or "Choose Alternate Battle Levels" depending on which you wish to play.
5) Scroll down the list and select huntbgn2.rtl or huntbgn2.rtc depending on which you wish to play and then hit space to select the level pack.
6) Once a check mark appears next to the levels, hit escape to back up, and then pick "Back to Main Menu" and hit enter.
7) Scroll down and select "Save and run ROTT" and enjoy!


INSTRUCTIONS FOR SHAREWARE VERSION
----------------------------------

1) Copy the two level files (huntbgn2.rtl & huntbgn2.rtc) to your Rise of the Triad game directory.
2) Rename the original shareware level files (huntbgin.rtl & huntbgin.rtc) to something else (it doesn't matter what).
3) Rename the new file huntbgn2.rtl to huntbgin.rtl
4) Rename the new file huntbgn2.rtc to huntbgin.rtc
5) Run the game as normal.
6) These new files contain all the same levels that are in your original ROTT shareware levels, plus the new ones.
6) Your original files are not needed, but should be kept as backups in case you run into problems.


IN CLOSING
----------

We hope you enjoy playing these 6 new Rise of the Triad levels.  Most of our ROTT fans probably have never seen these before, and with the release of these levels, there are now no remaining Rise of the Triad levels left over that have not already been released somewhere before.

For a complete listing of Rise of the Triad addons and level downloads, please visit our ROTT page on our website at http://www.3drealms.com/catalog/rott/

Thanks!

Joe Siegler
Apogee Software, Ltd.
